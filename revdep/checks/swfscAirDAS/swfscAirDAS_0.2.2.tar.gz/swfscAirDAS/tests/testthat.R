library(testthat)
library(swfscAirDAS)

test_check("swfscAirDAS")
