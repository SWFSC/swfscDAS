library(testthat)
library(CruzPlot)

test_check("CruzPlot")
